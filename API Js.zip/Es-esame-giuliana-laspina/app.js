const express = require('express');
const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

var channels = [
    {
        id: 1,
        name: "Rai1",
        programs: [
            {
                id: "a1",
                pro: "TG1"
                },
                {
                id: "a2",
                pro: "Uno Mattina"
                },
                {
                id: "a3",
                pro: "Don Matteo"
                },
                {
                id: "a4",
                pro: "I soliti ignoti"
                } 
            ]
    },
    {
        id: 2,
        name: "Rai2",
        programs: [
            {
            id: "a5",
            pro: "TG2"
            },
            {
            id: "a6",
            pro: "La vita in diretta"
            },
            {
            id: "a7",
            pro: "Magalli"
            },
            {
            id: "a8",
            pro: "Rai sport"
            }
        ]
    },
    {
        id: 3,
        name: "Rai3",
        programs: [
            {
            id: "a9",
            pro: "TG3"
            },
            { 
            id: "a10",
            pro:"La melevisione"
            }, 
            {
            id: "a11",
            pro:"Ulisse"
            }, 
            {
            id: "a12",
            pro:"Chi l'ha visto" 
        }]
    }
]



app.post('/channels',(req, res) => {
    var channel = req.body;
     channel.id = req.params.id; ;
     channels.push(channel);
     res.status(201).json(channel);
 });
 
app.get('/channels/:id', (req, res) => {
    var id = req.params.id;
    let channel = channels.find((item)=>item.id == id);
    res.json(channel);

})

app.get('/channels', (req, res) => {
  
    res.json(channels);
})

app.put('/channels/:id', (req, res) => {
    var id = req.params.id;
    var name = req.body.name;
    var index = channels.findIndex(item => item.id == id);
    channels[index].name = name;
    res.json(channels[index]);
})
app.delete('/channels/:id', (req, res) => {
    var index = channels.findIndex(item => item.id == req.params.id);
    channels.splice(index, 1);
    res.json(channels);
});


app.get('/channels/:id/programs', (req, res) => {
    var id = req.params.id;
    let channel = channels.find((item)=>item.id == id);
    res.json(channel.programs);

})

//aggiungere elementi ai programmi
app.post('/channels/:id/programs', (req,res) => {
    var index = channels.findIndex(item => item.id === req.params.id);
    channels[index].programs.push(req.body);
    res.json(channels[index].programs);
})

//cancellazione programmi
app.delete('/channels/:id/programs/:idPrograms', (req,res) => {
    var index = channels.findIndex(item => item.id === req.params.id);
    var indexPrograms = channels[index].programs.findIndex(item => item.id === req.params.idPrograms)
    channels[index].programs.splice(indexPrograms, 1);
    res.json(channels[index].programs);
})
app.listen(3001);